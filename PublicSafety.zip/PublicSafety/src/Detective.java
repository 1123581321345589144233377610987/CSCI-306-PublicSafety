
public class Detective {

}
