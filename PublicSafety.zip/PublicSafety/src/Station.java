
public class Station {

}
